/*
 * hack to add missing namespaces
 */
window.mapfish = {};
window.Ext = {
    get: function() {return null;}
};
