=================
Prerequisites
=================
***************
Python
***************
geojson:

::

 pip install geojson

Shapely:

::

 pip install Shapely==1.2.13
    
For Mac user: do not forget the following directive:

::

 ARCHFLAGS="-arch i386 -arch x86_64"
 
 
***************
PostGIS 1.5
***************

Please refer to `PostGIS installation directive <http://postgis.refractions.net/docs/>`_ or to your OS package system.