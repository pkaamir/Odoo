[![Build Status](https://travis-ci.org/OCA/e-commerce.svg?branch=7.0)](https://travis-ci.org/OCA/e-commerce)
[![Coverage Status](https://coveralls.io/repos/OCA/e-commerce/badge.png?branch=7.0)](https://coveralls.io/r/OCA/e-commerce?branch=7.0)

Odoo E-Commerce Modules
=======================

Modules aiming to support e-commerce specific needs.
